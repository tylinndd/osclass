#!/bin/bash
echo "============================================"
echo "SUCCESS"
echo "============================================"
echo ""
echo "Here is your key for the next steps:"
echo "KEY-775-EXEC" > key_file.txt
echo "File 'key_file.txt' has been created."
